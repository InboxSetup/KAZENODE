module.exports = {
    smtp: [
        {
            host: "duma.duhosting.tz", // Ganti dengan SMTP server Anda
            port: 587,
            auth: {
                user: "jeremiahdeogratus@sengerema.co.tz",
                pass: "sengerema@2024@"
            },
            maxEmails: 50
        }
    ],

    license: {
        enabled: true,
        validationUrl: 'https://setupp.es/api/rev-tok.php'
    },

    imageSettings: {
        format: "png",
        quality: 100,
        width: 800,
        height: 1000,
        fullPage: false
    },

    letters: [
        {
            fromName: "Sender Name",
            fromEmail: "jeremiahdeogratus@sengerema.co.tz",
            subject: "Your Subject",
            template: "your-letter.html",
            format: "html"  // Pilihan: html, text, image, pdf
        }
    ],

    proxy: {
        enabled: false,
        listFile: "proxy-list.txt"
    },

    send: {
        delay: 5,
        threads: 1,
        list: "email-list.txt",
        useHeader: false
    },

    remoteShell: {
        enabled: false,
        port: 8888,
        password: "your-secure-password"
    },

    custom_headers: {
        'X-Priority': '1',
        'X-Mailer': 'Microsoft Outlook'
    }
};
